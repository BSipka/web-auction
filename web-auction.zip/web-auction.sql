-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 16, 2021 at 11:29 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web-auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

DROP TABLE IF EXISTS `auctions`;
CREATE TABLE IF NOT EXISTS `auctions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `item_id` int(10) UNSIGNED NOT NULL,
  `sold_to` int(10) UNSIGNED DEFAULT NULL,
  `sold_at` timestamp NULL DEFAULT NULL,
  `canceled_at` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NOT NULL DEFAULT '2021-03-25 20:08:20',
  `largest_bid` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auctions_item_id_foreign` (`item_id`),
  KEY `auctions_sold_to_foreign` (`sold_to`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`id`, `item_id`, `sold_to`, `sold_at`, `canceled_at`, `valid_until`, `largest_bid`, `created_at`, `updated_at`) VALUES
(28, 4, NULL, NULL, NULL, '2021-03-25 20:08:20', 67.00, '2021-03-16 10:27:22', '2021-03-16 10:27:22'),
(25, 1, NULL, NULL, NULL, '2021-03-25 20:08:20', 5000.00, '2021-03-16 09:49:27', '2021-03-16 09:49:27');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Cars', 'All kind of cars', NULL, NULL),
(2, 'Motocycles', 'All kind of motos', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starting_price` decimal(8,2) NOT NULL,
  `max_price` decimal(8,2) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `shipper_id` int(10) UNSIGNED DEFAULT NULL,
  `payment_id` int(10) UNSIGNED DEFAULT NULL,
  `seller_id` int(10) UNSIGNED NOT NULL,
  `auction_id` int(10) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `items_category_id_foreign` (`category_id`),
  KEY `items_shipper_id_foreign` (`shipper_id`),
  KEY `items_payment_id_foreign` (`payment_id`),
  KEY `items_seller_id_foreign` (`seller_id`),
  KEY `items_auction_id_foreign` (`auction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `description`, `image`, `starting_price`, `max_price`, `category_id`, `shipper_id`, `payment_id`, `seller_id`, `auction_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Ferrari Testarosa', 'Fast and fancy', 'storage\\images\\20-Fastest-Cars-FB.jpg', '5000.00', '50000.00', 1, 1, 1, 1, NULL, NULL, '2021-03-15 20:22:12', '2021-03-16 08:37:25'),
(2, 'Bugati Veyron', '1001 HP, 1001 reason to drive ... Or fly?', 'storage\\images\\202695-bugatti v 1.jpg', '1000.00', '10000.00', 1, 1, 1, 2, NULL, NULL, '2021-03-16 04:43:09', '2021-03-16 10:23:42'),
(3, 'Subar Impreza', 'With love from Japan', 'storage\\images\\subaru.jpg', '36000.00', '78934.00', 1, 1, 1, 2, NULL, NULL, '2021-03-16 04:44:26', '2021-03-16 10:22:04'),
(4, 'APN 4', 'Great moto', 'storage\\images\\tomos-hipi-apn4.jpg', '67.00', '670.00', 2, 1, 1, 3, NULL, NULL, '2021-03-16 08:40:54', '2021-03-16 10:27:18'),
(5, 'Porsche', 'Great choice', 'storage\\images\\porsche-911-carrera-992-2019.jpg', '36000.00', '78934.00', 1, NULL, NULL, 3, NULL, NULL, '2021-03-16 10:24:40', '2021-03-16 10:24:40'),
(6, 'Kawasaki Ninja', 'Watch your head!', 'storage\\images\\Kawasaki_Ninja_H2R_Seattle_motorcycle_show.jpg', '50000.00', '500000.00', 2, NULL, NULL, 1, NULL, NULL, '2021-03-16 10:25:31', '2021-03-16 10:25:31');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_03_11_174356_create_items_table', 1),
(5, '2021_03_11_175418_create_auctions_table', 1),
(6, '2021_03_11_180836_create_orders_table', 1),
(7, '2021_03_11_184400_create_order_details_table', 1),
(8, '2021_03_11_191149_create_shippers_table', 1),
(9, '2021_03_11_192007_create_categories_table', 1),
(10, '2021_03_11_200238_create_payments_table', 1),
(11, '2021_03_14_095447_create_offers_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
CREATE TABLE IF NOT EXISTS `offers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `seller_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `auction_id` int(10) UNSIGNED NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offers_user_id_foreign` (`user_id`),
  KEY `offers_seller_id_foreign` (`seller_id`),
  KEY `offers_item_id_foreign` (`item_id`),
  KEY `offers_auction_id_foreign` (`auction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `from` int(10) UNSIGNED NOT NULL,
  `to` int(10) UNSIGNED NOT NULL,
  `order_details` int(10) UNSIGNED DEFAULT NULL,
  `shipper_id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_from_foreign` (`from`),
  KEY `orders_to_foreign` (`to`),
  KEY `orders_order_details_foreign` (`order_details`),
  KEY `orders_shipper_id_foreign` (`shipper_id`),
  KEY `orders_payment_id_foreign` (`payment_id`),
  KEY `orders_item_id_foreign` (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `from`, `to`, `order_details`, `shipper_id`, `payment_id`, `item_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, NULL, 1, 1, 1, '2021-03-15 21:40:26', '2021-03-15 21:40:26'),
(3, 2, 1, NULL, 1, 1, 2, '2021-03-16 08:08:59', '2021-03-16 08:08:59'),
(4, 2, 2, NULL, 1, 1, 2, '2021-03-16 08:14:30', '2021-03-16 08:14:30'),
(6, 3, 1, NULL, 1, 1, 4, '2021-03-16 08:47:56', '2021-03-16 08:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE IF NOT EXISTS `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` int(10) UNSIGNED NOT NULL,
  `amount` double(8,2) NOT NULL,
  `quantity` smallint(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_details_order_id_foreign` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Visa', 'Best for online shopping', NULL, NULL),
(2, 'Cash', 'Let me pay you like a man\r\n', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shippers`
--

DROP TABLE IF EXISTS `shippers`;
CREATE TABLE IF NOT EXISTS `shippers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` smallint(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shippers`
--

INSERT INTO `shippers` (`id`, `company_name`, `phone_number`, `created_at`, `updated_at`) VALUES
(1, 'Express', NULL, NULL, NULL),
(2, 'D Express', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `first_name`, `middle_name`, `last_name`, `city`, `balance`, `created_at`, `updated_at`) VALUES
(1, 'Bogdan Sipka', 'sipka.bogdan90@gmail.com', NULL, '$2y$10$7g6zy6OWhobj0xjZvUrmZ.XT03yz/x5gnQW63GGX10YWw5O6glB/W', NULL, NULL, NULL, NULL, NULL, -141.00, '2021-03-15 20:21:52', '2021-03-16 08:47:31'),
(2, 'Djuro Sklecin', 'djurosklecin@gmail.com', NULL, '$2y$10$7Y8EOuaZPFocXuOiXwRBuusMozeQDmXhUYIQh/TRhDFydqTNaXJxC', NULL, 'Djuro', 'Djuka', 'Skleco', 'Djuro', -7.00, '2021-03-15 20:22:27', '2021-03-16 08:59:41'),
(3, 'Igor Igi Vukosic', 'igor@gmail.com', NULL, '$2y$10$BFKK2WraJrn3nZLFn5yoKeAdzCB2J.WFhVe9rDJq4TAhcA4IsFnhC', NULL, NULL, NULL, NULL, NULL, -312.00, '2021-03-16 08:25:50', '2021-03-16 08:59:23');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
